#!/usr/bin/env bash
set -euo pipefail
mkdir -p _briefings tools/codex_prompts docs
echo "Briefings directories ready. Open docs/BRIEFINGS_WORKFLOW.md to continue."
